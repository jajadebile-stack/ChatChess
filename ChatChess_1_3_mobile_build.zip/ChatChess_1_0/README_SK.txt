CHATCHESS 1.2 – Android zdrojový projekt

ČO OBSAHUJE:
- úvodnú obrazovku aplikácie
- povolenie pre zobrazovanie nad ostatnými aplikáciami
- presúvateľnú plávajúcu bublinu a rozbaliteľný panel
- šachovnicu a načítanie rozloženia figúrok z FEN
- UCI komunikáciu so Stockfish
- tlačidlo na analýzu pozície a zobrazenie najlepšieho ťahu, hodnotenia a variantu
- nastavenie enginu na 2 vlákna a 64 MB hash pamäte

DÔLEŽITÉ – STAV:
- Toto je zdrojový projekt, nie hotový APK.
- Samotný spustiteľný Stockfish ARM64 súbor nie je priložený.
- Analýza začne fungovať až po vložení kompatibilného Android ARM64 enginu do:
  app/src/main/jniLibs/arm64-v8a/libstockfish.so
- Oficiálne zdroje Stockfish: https://github.com/official-stockfish/Stockfish/releases
- Stockfish je GPLv3. Ak sa jeho binárny súbor bude distribuovať spolu s ChatChess, treba priložiť GPLv3 licenciu a zodpovedajúci zdrojový kód (alebo platný odkaz naň) pre presne tú použitú verziu.

KOMPATIBILITA:
- Projekt je nastavený pre ARM64 Android zariadenia, vrátane Samsung Galaxy S21 5G.
- Na telefóne musí používateľ povoliť zobrazovanie nad ostatnými aplikáciami.

OBMEDZENIA:
- Automatické rozpoznávanie šachovnice zo snímky obrazovky zatiaľ nie je dostupné.
- Pozícia sa zadáva ručne cez FEN.
- FEN parser kontroluje rozloženie figúrok a počet polí v riadkoch, nie všetky šachové pravidlá.
- Projekt zatiaľ nebol zostavený pomocou Android SDK/Gradle a nebol otestovaný na fyzickom telefóne.
- Overlay je určený na tréning a štúdium vlastných pozícií, nie na skryté napovedanie v hodnotených online hrách.

ZOSTAVENIE APK:
1. Otvor projekt v Android Studio.
2. Počkaj na Gradle Sync.
3. Zvoľ Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK bude v app/build/outputs/apk/debug/ po úspešnom zostavení.

Na zostavenie je potrebné kompatibilné Android SDK, JDK a prístup na stiahnutie Gradle pluginov.

MOBILNÉ ZOSTAVENIE CEZ GITHUB ACTIONS (bez vlastného PC):
1. V mobile otvor https://github.com a prihlás sa alebo si vytvor účet (ak spĺňaš podmienky služby).
2. Vytvor nový súkromný repozitár s názvom ChatChess.
3. Nahraj celý obsah priečinka ChatChess_1_0 z tohto ZIP-u do koreňa repozitára. Nahraj aj skrytý priečinok .github.
4. Otvor kartu Actions, vyber „Build ChatChess APK“ a stlač „Run workflow“.
5. Po úspešnom zostavení otvor daný beh a v časti Artifacts stiahni „ChatChess-debug-apk“.

POZOR: Tento workflow zostaví APK aplikácie, ale samotná analýza Stockfish nebude fungovať, kým nebude pridaný kompatibilný Android ARM64 spustiteľný súbor do app/src/main/jniLibs/arm64-v8a/libstockfish.so. Zatiaľ ho projekt neobsahuje. APK preto nie je finálna verzia s funkčným enginom.

GitHub Actions je cloudové zostavenie; používateľ stále musí sám nahrať projekt do svojho účtu. Nikdy nezdieľaj heslo ani prihlasovacie kódy.
