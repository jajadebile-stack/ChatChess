package com.chatchess.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.View

class FenBoardView(context: Context, private var fen: String = START_FEN) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pieces = mapOf(
        'K' to "♔", 'Q' to "♕", 'R' to "♖", 'B' to "♗", 'N' to "♘", 'P' to "♙",
        'k' to "♚", 'q' to "♛", 'r' to "♜", 'b' to "♝", 'n' to "♞", 'p' to "♟"
    )
    private var squares = Array(8) { CharArray(8) { ' ' } }

    init { setFen(fen) }

    fun setFen(value: String): Boolean {
        val placement = value.trim().split(Regex("\\s+")).firstOrNull() ?: return false
        val ranks = placement.split("/")
        if (ranks.size != 8) return false
        val next = Array(8) { CharArray(8) { ' ' } }
        try {
            ranks.forEachIndexed { row, rank ->
                var col = 0
                rank.forEach { c ->
                    if (c in '1'..'8') col += c.digitToInt()
                    else {
                        if (c !in "prnbqkPRNBQK" || col >= 8) throw IllegalArgumentException()
                        next[row][col++] = c
                    }
                }
                if (col != 8) throw IllegalArgumentException()
            }
        } catch (_: Exception) { return false }
        squares = next
        fen = value
        invalidate()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cell = minOf(width, height) / 8f
        val left = (width - cell * 8) / 2f
        val top = (height - cell * 8) / 2f
        for (r in 0..7) for (c in 0..7) {
            val x = left + c * cell
            val y = top + r * cell
            paint.color = if ((r + c) % 2 == 0) Color.rgb(238, 218, 181) else Color.rgb(181, 136, 99)
            canvas.drawRect(x, y, x + cell, y + cell, paint)
            val piece = pieces[squares[r][c]] ?: ""
            if (piece.isNotEmpty()) {
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = cell * .72f
                paint.color = if (squares[r][c].isUpperCase()) Color.WHITE else Color.rgb(25, 25, 30)
                paint.setShadowLayer(1.5f, 0f, 1f, Color.BLACK)
                canvas.drawText(piece, x + cell / 2, y + cell * .75f, paint)
                paint.clearShadowLayer()
            }
        }
    }

    companion object {
        const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    }
}
