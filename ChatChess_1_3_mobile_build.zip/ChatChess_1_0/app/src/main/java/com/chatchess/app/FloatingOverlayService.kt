package com.chatchess.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class FloatingOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: View? = null
    private var board: FenBoardView? = null
    private var fenInput: EditText? = null
    private var analysisText: TextView? = null
    private lateinit var engine: StockfishEngine
    private val purple = Color.rgb(116, 91, 220)
    private val dark = Color.rgb(24, 26, 40)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        engine = StockfishEngine(this)
        showBubble()
    }

    private fun params(w: Int, h: Int, flags: Int = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) =
        WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14); y = dp(180)
        }

    private fun showBubble() {
        if (bubble != null) return
        val v = TextView(this).apply {
            text = "♟"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(purple)
            elevation = dp(8).toFloat()
            setOnClickListener { togglePanel() }
        }
        val p = params(dp(60), dp(60))
        drag(v, p)
        wm.addView(v, p)
        bubble = v
    }

    private fun drag(view: View, p: WindowManager.LayoutParams) {
        var sx = 0f; var sy = 0f; var px = 0; var py = 0; var moved = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; px = p.x; py = p.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(7)) moved = true
                    p.x = px + dx; p.y = py + dy
                    wm.updateViewLayout(view, p); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) view.performClick(); true }
                else -> false
            }
        }
    }

    private fun togglePanel() {
        if (panel != null) { closePanel(); return }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(dark)
            elevation = dp(12).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "♟ ChatChess"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val minimize = Button(this).apply {
            text = "—"
            setOnClickListener { closePanel() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        header.addView(minimize, LinearLayout.LayoutParams(dp(54), dp(44)))
        root.addView(header)

        val tabs = TextView(this).apply {
            text = "TRÉNING  •  POZÍCIA  •  POZNÁMKY"
            textSize = 11f
            setTextColor(Color.rgb(190, 175, 255))
            setPadding(0, dp(8), 0, dp(10))
        }
        root.addView(tabs)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        board = FenBoardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(250))
        }
        content.addView(board)

        val status = TextView(this).apply {
            text = "Tréningová pozícia – štandardné rozostavenie"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, dp(10), 0, dp(8))
        }
        content.addView(status)

        fenInput = EditText(this).apply {
            hint = "Vlož FEN pozície"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 12f
            setSingleLine(false)
            setBackgroundColor(Color.rgb(39, 42, 59))
        }
        content.addView(fenInput, LinearLayout.LayoutParams(-1, dp(76)))

        val load = Button(this).apply {
            text = "Načítať pozíciu z FEN"
            setOnClickListener {
                val value = fenInput?.text?.toString()?.trim().orEmpty()
                val ok = board?.setFen(value) ?: false
                status.text = if (ok) "Pozícia načítaná. Ide o zobrazenie pozície, nie engine analýzu."
                    else "FEN nie je platný alebo má nesprávne rozloženie."
            }
        }
        content.addView(load)

        val analyze = Button(this).apply {
            text = "Analyzovať pozíciu (Stockfish)"
            setOnClickListener {
                val fen = fenInput?.text?.toString()?.trim().takeUnless { it.isNullOrBlank() }
                    ?: FenBoardView.START_FEN
                if (!engine.isInstalled()) {
                    analysisText?.text = "Chýba Stockfish ARM64 engine. Umiestni oficiálny Android ARM64 engine ako app/src/main/jniLibs/arm64-v8a/libstockfish.so a znovu zostav aplikáciu."
                } else {
                    analysisText?.text = "Analyzujem pozíciu…"
                    engine.analyze(fen) { result ->
                        android.os.Handler(mainLooper).post {
                            analysisText?.text = result.fold(
                                { a -> "Najlepší ťah: ${a.bestMove}\nHodnotenie: ${a.evaluation}\nVariant: ${a.principalVariation.ifBlank { "—" }}" },
                                { e -> "Analýza zlyhala: ${e.message ?: "neznáma chyba"}" }
                            )
                        }
                    }
                }
            }
        }
        content.addView(analyze)

        analysisText = TextView(this).apply {
            text = "Stockfish: kontrolujem dostupnosť pri spustení analýzy. Určené na tréning a štúdium vlastných pozícií."
            textSize = 12f
            setTextColor(Color.rgb(215, 210, 245))
            setPadding(0, dp(12), 0, dp(8))
        }
        content.addView(analysisText)

        val explanation = TextView(this).apply {
            text = "ChatChess zobrazuje pozície z FEN a obsahuje UCI napojenie pre Stockfish. Rozpoznávanie šachovnice priamo z obrazovky zatiaľ nie je dostupné."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, dp(8))
        }
        content.addView(explanation)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val close = Button(this).apply {
            text = "Zavrieť ChatChess"
            setOnClickListener { stopSelf() }
        }
        root.addView(close)
        val p = params(dp(320), dp(520), 0)
        p.gravity = Gravity.TOP or Gravity.END
        p.x = dp(10); p.y = dp(100)
        wm.addView(root, p)
        panel = root
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; board = null; fenInput = null; analysisText = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
}
