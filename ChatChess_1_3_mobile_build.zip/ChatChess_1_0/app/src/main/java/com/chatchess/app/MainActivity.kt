package com.chatchess.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 18, 29)
    private val purple = Color.rgb(116, 91, 220)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(42), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "♟  ChatChess"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "Tvoj šachový tréningový pomocník"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(28))
        }
        val features = TextView(this).apply {
            text = "• Plávajúca bublina\n• Šachovnica a FEN pozície\n• Tréningový panel\n• Poznámky k vlastným partiám"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(29, 32, 48))
        }
        val permission = button("Povoliť plávajúce okno") {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else startOverlay()
        }
        val launch = button("Spustiť ChatChess") {
            if (Settings.canDrawOverlays(this@MainActivity)) startOverlay()
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        val note = TextView(this).apply {
            text = "Poznámka: analýza vyžaduje samostatný Stockfish ARM64 engine. Automatické rozpoznávanie šachovnice z obrazovky zatiaľ nie je dostupné."
            textSize = 12f
            setTextColor(Color.rgb(190, 190, 205))
            setPadding(0, dp(24), 0, 0)
        }
        root.addView(title)
        root.addView(sub)
        root.addView(features)
        root.addView(permission)
        root.addView(launch)
        root.addView(note)
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
        setTextColor(Color.WHITE)
        setBackgroundColor(purple)
        val lp = LinearLayout.LayoutParams(-1, dp(54))
        lp.topMargin = dp(14)
        layoutParams = lp
    }

    private fun startOverlay() {
        if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, FloatingOverlayService::class.java))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
