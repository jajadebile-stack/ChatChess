package com.chatchess.app

import android.content.Context
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.atomic.AtomicBoolean

/** Small UCI bridge for an Android ARM64 Stockfish executable packaged as libstockfish.so. */
class StockfishEngine(context: Context) {
    private val executable = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")
    private val busy = AtomicBoolean(false)

    data class Analysis(
        val bestMove: String,
        val evaluation: String,
        val principalVariation: String
    )

    fun isInstalled(): Boolean = executable.exists() && executable.canExecute()

    fun analyze(fen: String, moveTimeMs: Int = 1200, callback: (Result<Analysis>) -> Unit) {
        if (!busy.compareAndSet(false, true)) {
            callback(Result.failure(IllegalStateException("Analýza už prebieha.")))
            return
        }
        Thread {
            try {
                if (!isInstalled()) {
                    throw IllegalStateException("Chýba Stockfish ARM64 engine. Súbor libstockfish.so musí byť zabalený v jniLibs/arm64-v8a/.")
                }
                callback(Result.success(runAnalysis(fen, moveTimeMs.coerceIn(300, 2500))))
            } catch (t: Throwable) {
                callback(Result.failure(t))
            } finally {
                busy.set(false)
            }
        }.start()
    }

    private fun runAnalysis(fen: String, moveTimeMs: Int): Analysis {
        val process = ProcessBuilder(executable.absolutePath)
            .directory(executable.parentFile)
            .redirectErrorStream(true)
            .start()
        val writer = OutputStreamWriter(process.outputStream)
        val reader = BufferedReader(InputStreamReader(process.inputStream))
        fun send(command: String) {
            writer.write(command)
            writer.write("\n")
            writer.flush()
        }
        fun waitFor(token: String) {
            while (true) {
                val line = reader.readLine() ?: throw IllegalStateException("Stockfish sa neočakávane ukončil.")
                if (line.trim() == token) return
            }
        }

        try {
            send("uci")
            waitFor("uciok")
            send("setoption name Threads value 2")
            send("setoption name Hash value 64")
            send("isready")
            waitFor("readyok")
            send("position fen $fen")
            send("go movetime $moveTimeMs")

            var evaluation = "Hodnotenie sa nepodarilo načítať"
            var pv = ""
            while (true) {
                val line = reader.readLine() ?: throw IllegalStateException("Stockfish prerušil analýzu.")
                if (line.startsWith("info ") && line.contains(" score ")) {
                    // Keep the most recent completed search information. Stockfish may emit
                    // several depth updates; the last one before bestmove is the useful one.
                    evaluation = parseScore(line)
                    val pvIndex = line.indexOf(" pv ")
                    if (pvIndex >= 0) pv = line.substring(pvIndex + 4).trim()
                }
                if (line.startsWith("bestmove ")) {
                    val bestMove = line.split(Regex("\\s+")).getOrNull(1) ?: "?"
                    return Analysis(bestMove, evaluation, pv)
                }
            }
        } finally {
            try { send("quit") } catch (_: Exception) { }
            try { process.destroy() } catch (_: Exception) { }
            try { reader.close() } catch (_: Exception) { }
            try { writer.close() } catch (_: Exception) { }
        }
    }

    private fun parseScore(line: String): String {
        val parts = line.split(Regex("\\s+"))
        val scoreIndex = parts.indexOf("score")
        if (scoreIndex < 0 || scoreIndex + 2 >= parts.size) return "Hodnotenie sa nepodarilo načítať"
        return when (parts[scoreIndex + 1]) {
            "cp" -> {
                val pawns = (parts[scoreIndex + 2].toDoubleOrNull() ?: return "—") / 100.0
                "${if (pawns > 0) "+" else ""}${"%.2f".format(java.util.Locale.US, pawns)} pešiaka (hráč na ťahu)"
            }
            "mate" -> "Mat za ${parts[scoreIndex + 2]} ťahov (hráč na ťahu)"
            else -> "—"
        }
    }
}
